package carbon.widget;

/**
 * Created by Marcin on 2015-01-13.
 */
public interface OnValidateListener {
    boolean onValidate(String s);
}
