package carbon.beta;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Created by Marcin on 2015-01-17.
 */
@Retention(RetentionPolicy.RUNTIME)
public @interface SaveState {
}